

# fixed arguments


# function body
def display(a,b):
    print(a,b)


# calling function
display(10,20)