import pymysql
import csv
import configparser
import sys
import os

parser  = configparser.ConfigParser()
parser.read('db_info.conf')

### reading from config file 
hostname = parser.get('database', 'host')
username = parser.get('database','user')
password = parser.get('database','password')
portno = parser.get('database','port')
filename = "realestate.csv"
try:
    ## step1
    db = pymysql.connect(host=hostname,port=int(portno), user=username,password=password,database='epsilon')
    
    if db:
        print("successfully connected to DB")
        if os.path.exists(filename) and os.path.isfile(filename):
            with open(filename,"r") as fobj:
                reader = csv.reader(fobj)
                for line in reader:
                    street = line[0]
                    city = line[1]
                    ## step2: create your cursor for navigating the records
                    cursor = db.cursor()
                    ## step3: define your query
                    query = "insert into realestate values('{}','{}')".format(street,city)
                    ## step4: execute
                    cursor.execute(query)
        else:
            print("file doesn't exist")
            print("terminating from the program")
            sys.exit(1)
    else:
        print("DB not available")
            
    db.commit()
    db.close()
except pymysql.DatabaseError as err:
    print(err)
except pymysql.OperationalError as err:
    print(err)
except (pymysql.DataError, pymysql.IntegrityError) as err:
    print(err)
except Exception as err:
    print(err)





