



import pymysql

import configparser
parser  = configparser.ConfigParser()
parser.read('db_info.conf')

### reading from config file 
hostname = parser.get('database', 'host')
username = parser.get('database','user')
password = parser.get('database','password')
portno = parser.get('database','port')

try:
    ## step1
    db = pymysql.connect(host=hostname,port=int(portno), user=username,password=password)
    
    if db:
        print("successfully connected to DB")
        ## step2: create your cursor for navigating the records
        cursor = db.cursor()
        ## step3: define your query
        query = "select * from epsilon.realestate"
        ## step4: execute
        cursor.execute(query)
        ## step5: fetch
        for record in cursor.fetchall():
            print(record[0])
            print(record[1])
            print("------")
        
    db.close()
except Exception as err:
    print(err)
