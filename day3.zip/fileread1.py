


#fobj is file handler or file object or file reference
with open("customers3333.txt","r") as fobj:
    for line in fobj:
        line = line.strip()  # remove whitespace if any
        print(line)

        
    
# using fobj.readlines()
with open("customers.txt","r") as fobj:
    print(fobj.readlines())
    

# using read()
with open("customers.txt","r") as fobj:
    print(fobj.read())
    
    
# using csv library
import csv


# fobj can be called as file object or cursor or file reference
with open("customers.txt","r") as fobj:
    # converting fobj(file object) to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        
    










