



import pymysql
try:
    ## step1
    db = pymysql.connect(host='localhost',port=3306, user='root',password='india@123',database='epsilon')
    
    if db:
        print("successfully connected to DB")
        ## step2: create your cursor for navigating the records
        cursor = db.cursor()
        ## step3: define your query
        with open("queries.txt","r") as fobj:
            for query in fobj:
                query = query.strip()
                
                cursor.execute(query)
                ## step5: fetch
                for record in cursor.fetchall():
                    print(record[0])
                    print(record[1])
                    print("------")
        
    db.close()
except Exception as err:
    print(err)
