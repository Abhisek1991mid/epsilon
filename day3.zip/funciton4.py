# variable length arguments



def display(*params):
    for val in params:
        print(val)

display(10,20,30,40,"linux",60,70,80,90,100,"unix")



def newDisplay(**book):
    for key,value in book.items():
        print(key,value)

newDisplay(chap1=10 , chap2=20)