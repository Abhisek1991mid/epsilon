


import os

print(os.getcwd())

#os.unlink("realestate.csv")


import os

print(os.stat("fileread1.py"))

print(os.path.getsize("fileread1.py"))




for file in os.listdir():
    if file.endswith(".zip") and os.path.getsize(file) > 0 :
        print(file)
    
 