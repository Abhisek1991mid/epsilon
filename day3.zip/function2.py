# defualt arguments


# function body
def display(a=0,b=0,c=1):
    print(a,b,c)


# calling function
display()
display(0)
display(0,0)
display(0,0,0)

              
print(list(range(10)))  # start=0 , stop = 10 , step =1
print(list(range(1,10)))# start=1   stop = 10   step = 1
print(list(range(1,10,2)))#start=1s  stop = 10  step = 2

print("hello","hi",sep="      ")
print("hi")
print()
print(1,2)