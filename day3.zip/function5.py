

# function body
def add(a,b):
    c = a + b
    return c

total = add(10,20)





# lambda function
# lambda is an inline function like in java or C++
# Instead of calling the funtion body ... the function will be 
#                                          replaced in the function call

#function = lambda variables:expression
add = lambda x,y : x + y
print(add(10,20))



name = "python"
toupper = lambda lang : lang.upper()
print(toupper(name))


#map() and filter()

alist  = [10,20,30]
#Output  [15,25,35]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)


#map(function,iterable)
alist  = [10,20,30]
print(list(map(lambda x:x+5, alist)))


alist = [1,2,3,4,5,6]
print(list(filter(lambda x:x%2, alist)))






    








