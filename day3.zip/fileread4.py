



try:
    #fobj is file handler or file object or file reference
    with open("customers.txt","r") as fobj:
        for line in fobj:
            line = line.strip()  # remove whitespace if any
            print(line)
    output = 1 + "hello"
except FileNotFoundError as error:
    print("File doesn't exist")
    print("System error :",error)
except TypeError as err:
    print(err)
except (ValueError,ZeroDivisionError) as err:
    print(err)
except Exception as err:
    print("this is the default exception")
    print(err)
        