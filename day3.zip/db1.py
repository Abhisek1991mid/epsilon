


import pymysql
try:
    ## step1
    db = pymysql.connect(user='root',port=3306, host='localhost',password='india@123',database='epsilon')
    
    if db:
        print("successfully connected to DB")
        ## step2: create your cursor for navigating the records
        cursor = db.cursor()
        ## step3: define your query
        query = "select * from realestate"
        ## step4: execute
        cursor.execute(query)
        ## step5: fetch
        for record in cursor.fetchall():
            print(record[0])
            print(record[1])
            print("------")
        
    db.close()
except Exception as err:
    print(err)
