


alist = [10,20,30,56,6,10,10]


print(len(alist))


alist[0] = 1000
print(alist)


print(alist[0:5])
print(alist[:-1])


# adding one object
alist.append(78)
print("After appending:", alist)
alist.append(780)
print("After appending:", alist)

# adding iterable
alist.extend([54,56,34,2])
print("After extending:",alist)


print(alist.count(10))

# list.insert(location,value)
#             (where to insert, what to insert)
alist.insert(0,100)
print("After insert:",alist)
alist.insert(3,14)
print("After insert:",alist)

alist.pop()  #  will remove the last value
print(alist)
alist.pop(0)
print("After pop:",alist)



alist.remove(56)
print("after removing:",alist)



alist.sort()
print("After sorting :",alist)
alist.sort(reverse=True)
print("After sorting :",alist)

alist.reverse()
print(alist)








