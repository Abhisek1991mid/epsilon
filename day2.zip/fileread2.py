



import csv

filename = input("Enter any filename :")
with open(filename,"r") as fobj:
    # converting fobj(file object) to csv object
    if filename.endswith(".txt"):
        reader = csv.reader(fobj)
        for line in reader:
            print(line)

    else:
        print("file is ending with proper extension ")
        
    