

#fobj = open("D:/test/xyz/customers.txt","w")
#fobj = open(r"D:\test\xyz\customers.txt","w")   # raw string


fobj = open("customers.txt","w")

fobj.write("python programming\n")
fobj.write("scala programming\n")

fobj.close()




fobj = open("numbers.txt","w")
for val in range(1,10):
    fobj.write(str(val) + "\n")

fobj.close()


############## 2nd approach
## context manager
## file gets closed automatically  ( NOT required to close the file)
with open("customers1.txt","w") as fobj:
    fobj.write("python programming\n")
    fobj.write("scala programming\n")    
 
    
 
    
 
    
 
    
 
'''
# db programming       pymysql.connect(host,user,password,database)
                       db.close()
                       
                       
                       with  pymysql.connect(host,user,password,database) as db:
# network programming
'''











