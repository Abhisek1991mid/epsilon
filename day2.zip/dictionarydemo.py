





book = {"chap1":10,"chap2":20 ,"chap3":30 ,"chap1":1000}

print(book)

print(len(book))



book["chap4"] = 40
book["chap5"] = 50
book["chap1"] = [4000,3]


print(book)

# ONLY keys
print(book.keys())

# ONLY values
print(book.values())

#items
print(book.items())


#print(book["chap10"])

#print(book.get("chap10"))


book2 = {"chap6":60 ,"chap7":70}



val = str(1) + str(2)
print(val)

name = "python" + "programming"
print(name)

data = [10,20]+ [30,40]
print(data)

info = (10,20) + (30,40)
print(info)

#1st approach
finalbook = {**book,**book2}
print(finalbook)

# 2nd approach
book.update(book2)
print(book)






















