# using csv library
import csv
cityset = set()
filename = "realestate.csv"
with open(filename,"r") as fobj:
    # converting fobj(file object) to csv object
    reader = csv.reader(fobj)
    ## processing
    for line in reader:
        city = line[1]
        ## adding each unique city to the set
        cityset.add(city)
    ## displaying the unique cities
    for city in cityset:
        print(city)
    

import csv
citydict = dict()
filename = "realestate.csv"
with open(filename,"r") as fobj:
    # converting fobj(file object) to csv object
    reader = csv.reader(fobj)
    ## processing
    for line in reader:
        city = line[1]
        ## adding each unique city to the set
        citydict[city] = 1
    ## displaying the unique cities
    for city in citydict:
        print(city)
    
    

import csv
citylist = list()
filename = "realestate.csv"
with open(filename,"r") as fobj:
    # converting fobj(file object) to csv object
    reader = csv.reader(fobj)
    ## processing
    for line in reader:
        print(line)
        city = line[1]
        if city not in citylist:
            citylist.append(city)
    ## displaying the unique cities
    for city in citylist:
        print(city)    






