

data = {
	"name": "first-network",
	"version": "1.0.0",
	"client": {
		"tlsEnable": True,
        }
}



for key,value in data.items():
    if isinstance(value,str):
        print(key.ljust(10),value)
    elif isinstance(value,dict):
        for skey,svalue in value.items():
            print(skey.ljust(10),svalue)
            
            