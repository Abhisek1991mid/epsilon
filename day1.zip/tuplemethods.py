


atup = (10,20)

#atup[0] = 34

print("After modification :",atup)



# typecasting
# converted to list
alist = list(atup)
# making some changes
alist.append(1000)
# reconverting back to tuple
atup = tuple(alist)

print(atup)