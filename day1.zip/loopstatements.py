# display range of numbers
val = 10
for val in range(val,1,-1):
    print(val)
    
    
## iterate string
name = "python"
for char in name:
    print(char)
    
## iterate list
alist = [10,20,30]
for val in alist:
    print(val)
    
### iterate tuple
atup = ("unix","java")
for name in atup:
    print(name)

### ONLY keys
book = {"chap1":10,"chap2":20 ,"chap3":30 }
for key in book.keys():
    print(key, book[key])

    
### for Values    
for value in book.values():
    print(value)    
    
    
### key,value both    
for key,value in book.items():
    print(key,value)
    
    


    
    
    