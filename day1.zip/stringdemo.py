
#string[start:stop:step]
name = "python programming"
print(name[0]) # p
print(name[1]) # y
print(name[0:4])
print(name[4:7])
print(name[:])
print(name[::])
print(name[0:17:2])
print(name[1:17:2])
print(name[::3])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])  

print(name.count('prog'))
print(name.center(40))
print(name.upper())
print(name.lower())
print(name.replace("python","ruby"))  # displayed on the screen
print(name.isupper())
print(name.islower())

print(name.endswith("g"))


if name.endswith("g"):
    print("String is ending with g")
    print("Inside if")
else:
    print("String is something else")
    
    
if name.isupper():
    print("String is defined in upper")
elif name.islower():
    print("String is defined in lower()")
else:
    print("something else")
    
    
name = " python "
print(len(name))

print(len(name.strip()))   # will remove whitespace at both ends

print(len(name.lstrip()))










